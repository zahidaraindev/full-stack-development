/* ==========================================================================
   MERIDIAN ACADEMY — SCRIPT.JS
   Vanilla JS only. Organised by feature, each wrapped defensively so one
   missing element never breaks the rest of the page.
   ========================================================================== */

document.addEventListener('DOMContentLoaded', () => {

  /* ------------------------------------------------------------------ *
   * 1. FOOTER YEAR
   * ------------------------------------------------------------------ */
  const yearEl = document.getElementById('year');
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  /* ------------------------------------------------------------------ *
   * 2. STICKY NAVBAR SHADOW ON SCROLL
   * ------------------------------------------------------------------ */
  const navbar = document.getElementById('navbar');
  if (navbar) {
    const toggleNavbarShadow = () => {
      navbar.classList.toggle('is-scrolled', window.scrollY > 12);
    };
    toggleNavbarShadow();
    window.addEventListener('scroll', toggleNavbarShadow, { passive: true });
  }

  /* ------------------------------------------------------------------ *
   * 3. MOBILE NAVIGATION (HAMBURGER)
   * ------------------------------------------------------------------ */
  const hamburger = document.getElementById('hamburger');
  const navLinksEl = document.getElementById('navLinks');

  if (hamburger && navLinksEl) {
    const closeMenu = () => {
      hamburger.classList.remove('is-active');
      navLinksEl.classList.remove('is-open');
      hamburger.setAttribute('aria-expanded', 'false');
    };
    const toggleMenu = () => {
      const isOpen = navLinksEl.classList.toggle('is-open');
      hamburger.classList.toggle('is-active', isOpen);
      hamburger.setAttribute('aria-expanded', String(isOpen));
    };

    hamburger.addEventListener('click', toggleMenu);

    navLinksEl.querySelectorAll('.nav-link').forEach((link) => {
      link.addEventListener('click', closeMenu);
    });

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') closeMenu();
    });
  }

  /* ------------------------------------------------------------------ *
   * 4. SMOOTH SCROLL FOR ALL IN-PAGE ANCHOR LINKS
   * ------------------------------------------------------------------ */
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener('click', (e) => {
      const targetId = anchor.getAttribute('href');
      if (!targetId || targetId === '#') return;
      const target = document.querySelector(targetId);
      if (!target) return;
      e.preventDefault();
      const navHeight = navbar ? navbar.offsetHeight : 0;
      const top = target.getBoundingClientRect().top + window.scrollY - navHeight + 1;
      window.scrollTo({ top, behavior: 'smooth' });
    });
  });

  /* ------------------------------------------------------------------ *
   * 5. ACTIVE NAVIGATION LINK ON SCROLL
   * ------------------------------------------------------------------ */
  const sections = Array.from(document.querySelectorAll('main section[id]'));
  const navLinkEls = Array.from(document.querySelectorAll('.nav-link'));

  if (sections.length && navLinkEls.length) {
    const setActiveLink = () => {
      const scrollPos = window.scrollY + (navbar ? navbar.offsetHeight : 0) + 40;
      let currentId = sections[0].id;

      sections.forEach((section) => {
        if (scrollPos >= section.offsetTop) currentId = section.id;
      });

      navLinkEls.forEach((link) => {
        const isMatch = link.getAttribute('href') === `#${currentId}`;
        link.classList.toggle('active-link', isMatch);
      });
    };

    setActiveLink();
    window.addEventListener('scroll', setActiveLink, { passive: true });
  }

  /* ------------------------------------------------------------------ *
   * 6. SCROLL REVEAL ANIMATIONS
   * ------------------------------------------------------------------ */
  const revealEls = document.querySelectorAll('[data-reveal]');
  if (revealEls.length && 'IntersectionObserver' in window) {
    const revealObserver = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          revealObserver.unobserve(entry.target);
        }
      });
    }, { threshold: 0.15, rootMargin: '0px 0px -40px 0px' });

    revealEls.forEach((el) => revealObserver.observe(el));
  } else {
    revealEls.forEach((el) => el.classList.add('is-visible'));
  }

  /* ------------------------------------------------------------------ *
   * 7. COUNTER ANIMATION FOR STATISTICS
   * ------------------------------------------------------------------ */
  const counters = document.querySelectorAll('.stat-card__num');
  if (counters.length && 'IntersectionObserver' in window) {
    const animateCounter = (el) => {
      const target = parseInt(el.getAttribute('data-count'), 10) || 0;
      const suffix = el.getAttribute('data-suffix') || '';
      const duration = 1400;
      const start = performance.now();

      const step = (now) => {
        const progress = Math.min((now - start) / duration, 1);
        const eased = 1 - Math.pow(1 - progress, 3); // ease-out cubic
        const value = Math.round(target * eased);
        el.textContent = value + suffix;
        if (progress < 1) requestAnimationFrame(step);
      };
      requestAnimationFrame(step);
    };

    const counterObserver = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          animateCounter(entry.target);
          counterObserver.unobserve(entry.target);
        }
      });
    }, { threshold: 0.5 });

    counters.forEach((el) => counterObserver.observe(el));
  }

  /* ------------------------------------------------------------------ *
   * 8. COURSE FILTERING
   * ------------------------------------------------------------------ */
  const filterTabs = document.querySelectorAll('.filter-tab');
  const courseCards = document.querySelectorAll('.course-card');

  if (filterTabs.length && courseCards.length) {
    filterTabs.forEach((tab) => {
      tab.addEventListener('click', () => {
        filterTabs.forEach((t) => {
          t.classList.remove('is-active');
          t.setAttribute('aria-selected', 'false');
        });
        tab.classList.add('is-active');
        tab.setAttribute('aria-selected', 'true');

        const filter = tab.getAttribute('data-filter');
        courseCards.forEach((card) => {
          const match = filter === 'all' || card.getAttribute('data-category') === filter;
          card.classList.toggle('is-hidden', !match);
        });
      });
    });
  }

  /* ------------------------------------------------------------------ *
   * 9. TESTIMONIAL SLIDER
   * ------------------------------------------------------------------ */
  const track = document.getElementById('testimonialTrack');
  const dotsWrap = document.getElementById('testimonialDots');
  const prevBtn = document.getElementById('testimonialPrev');
  const nextBtn = document.getElementById('testimonialNext');

  if (track && dotsWrap && prevBtn && nextBtn) {
    const slides = Array.from(track.children);
    let current = 0;
    let autoplayId = null;

    slides.forEach((_, i) => {
      const dot = document.createElement('button');
      dot.setAttribute('aria-label', `Go to testimonial ${i + 1}`);
      if (i === 0) dot.classList.add('is-active');
      dot.addEventListener('click', () => goTo(i));
      dotsWrap.appendChild(dot);
    });
    const dots = Array.from(dotsWrap.children);

    function goTo(index) {
      current = (index + slides.length) % slides.length;
      track.style.transform = `translateX(-${current * 100}%)`;
      dots.forEach((d, i) => d.classList.toggle('is-active', i === current));
    }

    function startAutoplay() {
      stopAutoplay();
      autoplayId = setInterval(() => goTo(current + 1), 6000);
    }
    function stopAutoplay() {
      if (autoplayId) clearInterval(autoplayId);
    }

    prevBtn.addEventListener('click', () => { goTo(current - 1); startAutoplay(); });
    nextBtn.addEventListener('click', () => { goTo(current + 1); startAutoplay(); });

    track.parentElement.addEventListener('mouseenter', stopAutoplay);
    track.parentElement.addEventListener('mouseleave', startAutoplay);

    goTo(0);
    startAutoplay();
  }

  /* ------------------------------------------------------------------ *
   * 10. GALLERY LIGHTBOX
   * ------------------------------------------------------------------ */
  const lightbox = document.getElementById('lightbox');
  const lightboxImg = document.getElementById('lightboxImg');
  const lightboxCaption = document.getElementById('lightboxCaption');
  const lightboxClose = document.getElementById('lightboxClose');
  const galleryItems = document.querySelectorAll('.gallery-item');

  if (lightbox && lightboxImg && lightboxClose && galleryItems.length) {
    let lastFocused = null;

    const openLightbox = (item) => {
      const full = item.getAttribute('data-full');
      const caption = item.getAttribute('data-caption') || '';
      const imgEl = item.querySelector('img');

      lightboxImg.src = full || (imgEl ? imgEl.src : '');
      lightboxImg.alt = imgEl ? imgEl.alt : caption;
      if (lightboxCaption) lightboxCaption.textContent = caption;

      lastFocused = document.activeElement;
      lightbox.hidden = false;
      document.body.style.overflow = 'hidden';
      lightboxClose.focus();
    };

    const closeLightbox = () => {
      lightbox.hidden = true;
      document.body.style.overflow = '';
      if (lastFocused) lastFocused.focus();
    };

    galleryItems.forEach((item) => {
      item.addEventListener('click', () => openLightbox(item));
    });

    lightboxClose.addEventListener('click', closeLightbox);
    lightbox.addEventListener('click', (e) => {
      if (e.target === lightbox) closeLightbox();
    });
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && !lightbox.hidden) closeLightbox();
    });
  }

  /* ------------------------------------------------------------------ *
   * 11. BACK TO TOP BUTTON
   * ------------------------------------------------------------------ */
  const backToTop = document.getElementById('backToTop');
  if (backToTop) {
    window.addEventListener('scroll', () => {
      backToTop.classList.toggle('is-visible', window.scrollY > 480);
    }, { passive: true });

    backToTop.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  /* ------------------------------------------------------------------ *
   * 12. FORM VALIDATION — shared helper
   * ------------------------------------------------------------------ */
  function validateForm(form, rules) {
    let isValid = true;

    Object.keys(rules).forEach((fieldName) => {
      const field = form.elements[fieldName];
      if (!field) return;

      const wrapper = field.closest('.form-field');
      const errorEl = form.querySelector(`[data-error-for="${fieldName}"]`);
      const rule = rules[fieldName];
      const value = field.value.trim();
      let message = '';

      if (rule.required && !value) {
        message = rule.requiredMessage || 'This field is required.';
      } else if (value && rule.pattern && !rule.pattern.test(value)) {
        message = rule.patternMessage || 'This value looks incorrect.';
      }

      if (message) {
        isValid = false;
        if (wrapper) wrapper.classList.add('has-error');
        if (errorEl) errorEl.textContent = message;
      } else {
        if (wrapper) wrapper.classList.remove('has-error');
        if (errorEl) errorEl.textContent = '';
      }
    });

    return isValid;
  }

  /* ------------------------------------------------------------------ *
   * 13. ADMISSION FORM VALIDATION
   * ------------------------------------------------------------------ */
  const admissionForm = document.getElementById('admissionForm');
  const admissionSuccess = document.getElementById('admissionSuccess');

  if (admissionForm) {
    const admissionRules = {
      studentName: { required: true, requiredMessage: "Please enter the student's name." },
      fatherName: { required: true, requiredMessage: "Please enter the father's name." },
      phone: {
        required: true,
        requiredMessage: 'Please enter a phone number.',
        pattern: /^[0-9+\-\s()]{7,}$/,
        patternMessage: 'Please enter a valid phone number.'
      },
      email: {
        required: true,
        requiredMessage: 'Please enter an email address.',
        pattern: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
        patternMessage: 'Please enter a valid email address.'
      },
      course: { required: true, requiredMessage: 'Please select a course.' },
      classLevel: { required: true, requiredMessage: 'Please select a class.' }
    };

    admissionForm.addEventListener('submit', (e) => {
      e.preventDefault();
      if (admissionSuccess) admissionSuccess.hidden = true;

      const valid = validateForm(admissionForm, admissionRules);
      if (valid) {
        if (admissionSuccess) admissionSuccess.hidden = false;
        admissionForm.reset();
      } else {
        const firstError = admissionForm.querySelector('.has-error input, .has-error select');
        if (firstError) firstError.focus();
      }
    });
  }

  /* ------------------------------------------------------------------ *
   * 14. CONTACT FORM VALIDATION
   * ------------------------------------------------------------------ */
  const contactForm = document.getElementById('contactForm');
  const contactSuccess = document.getElementById('contactSuccess');

  if (contactForm) {
    const contactRules = {
      cName: { required: true, requiredMessage: 'Please enter your name.' },
      cEmail: {
        required: true,
        requiredMessage: 'Please enter your email.',
        pattern: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
        patternMessage: 'Please enter a valid email address.'
      },
      cMessage: { required: true, requiredMessage: 'Please write a short message.' }
    };

    contactForm.addEventListener('submit', (e) => {
      e.preventDefault();
      if (contactSuccess) contactSuccess.hidden = true;

      const valid = validateForm(contactForm, contactRules);
      if (valid) {
        if (contactSuccess) contactSuccess.hidden = false;
        contactForm.reset();
      } else {
        const firstError = contactForm.querySelector('.has-error input, .has-error textarea');
        if (firstError) firstError.focus();
      }
    });
  }

});
